# TraceGuide AI

Prototype website for digital safety, organized evidence, human support and community education.

## Local preview
Open `index.html` in a browser.

## GitHub Pages
Push the repository to GitHub on the `main` branch. The included GitHub Actions workflow deploys the static site to GitHub Pages.

## Important
This is a static prototype. Do not collect or store real sensitive case evidence in this repository. A production evidence vault requires secure backend infrastructure, authentication, encryption, access controls, retention/deletion controls, and security/privacy review.

Working brand: TraceGuide AI. Name/domain/trademark clearance is still required before public launch.
